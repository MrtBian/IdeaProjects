import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 * @date 18/11/13
 * @author Wing
 */
public class LocationServlet extends javax.servlet.http.HttpServlet {

    private String serverIP = "114.212.80.13";
    private String serverID = "Administrator";
    private String serverPwd = "NetLab624Admin";
    private String dbID = "sa";
    private String dbPwd = "NetLab624";
    private String dbName = "newMiniLibrary";

    @Override
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

        //网址格式：localhost:8080/BookLocation/location?barcode=xxxxxxx
        // 设置响应内容类型
        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();
        String title = "图书位置";
        // 处理中文
        String barcode = request.getParameter("barcode");
        String bookName = "", bookShelfID = "", bookLayer = "";

        //连接数据库
        String JDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        String connectDB = "jdbc:sqlserver://" + serverIP + ":1433;DatabaseName=" + dbName;
        Connection dbConn = null;
        try {
            //加载数据库引擎，返回给定字符串名的类
            Class.forName(JDriver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("加载数据库引擎失败");
            System.exit(0);
        }
        System.out.println("数据库驱动成功");
        //连接数据库对象
        Connection con = null;
        try {
            con = DriverManager.getConnection(connectDB, dbID, dbPwd);
        } catch (SQLException e) {

            System.out.println("连接数据库失败！");
            e.printStackTrace();
        }
        System.out.println("连接数据库成功");
        //创建SQL命令对象
        Statement stmt = null;
        try {
            stmt = con.createStatement();
            //读取数据
            System.out.println("开始读取数据");
            ResultSet rs = stmt.executeQuery("SELECT * FROM Book,BookCopy where Book.ID = BookCopy.BookID AND Barcode = \'" + barcode + "\'");
            //循环输出每一条记录
            while (rs.next()) {
                //输出每个字段
                bookName = rs.getString("Title");
                bookShelfID = rs.getString("ShelfID");
                bookLayer = rs.getString("Layer");
            }
            System.out.println("读取完毕");

            //关闭连接
            stmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        String docType = "<!DOCTYPE html> \n";
        out.println(docType +
                "<html>\n" +
                "<head><title>" + title + "</title></head>\n" +
                "<body bgcolor=\"#f0f0f0\">\n" +
                "<h1 align=\"center\">" + title + "</h1>\n" +
                "<ul>\n" +
                "  <li><b>Barcode:</b>："
                + barcode + "\n" +
                "  <li><b>BookName:</b>："
                + bookName + "\n" +
                "  <li><b>bookShelfID:</b>："
                + bookShelfID + "\n" +
                "  <li><b>bookLayer:</b>："
                + bookLayer + "\n" +
                "</ul>\n" +
                "</body></html>");
    }
}
