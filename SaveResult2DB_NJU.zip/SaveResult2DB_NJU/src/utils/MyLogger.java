package utils;

import org.apache.log4j.Logger;

/**
 * 日志类
 *
 * @author Wing
 * @date 2018.07.19
 */
public class MyLogger {
    public static final Logger LOGGER = Logger.getLogger(MyLogger.class.getName());
}

